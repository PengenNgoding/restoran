<?php
/**
 *
 * Theme sidebar
 *
 * @package   Doctreat
 * @author    amentotech
 * @link      https://themeforest.net/user/amentotech/portfolio
 * @version 1.0
 * @since 1.0
 */


if ( ! is_active_sidebar( 'sidebar-1' ) ) {
    return;
}

dynamic_sidebar( 'sidebar-1' ); 
?>



