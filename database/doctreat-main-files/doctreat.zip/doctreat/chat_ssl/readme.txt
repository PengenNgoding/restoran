Please download cert and private keys from your server and then replace with given files.

1. chat_cert
2. private.key

above files are sample files and have no content in it