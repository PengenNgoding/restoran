<?php
/**
 *
 * Footer Page
 *
 * @package   Doctreat
 * @author    amentotech
 * @link      https://themeforest.net/user/amentotech/portfolio
 * @since 1.0
 */
?>
<?php do_action('doctreat_do_process_footers');?>
<?php wp_footer(); ?>
</body></html>