<?php

if (!defined('FW')) {
    die('Forbidden');
}

$manifest = array();
$manifest['id'] = 'doctreat';
$manifest['supported_extensions'] = array(
	'backups' => array()
);
