=====Init Release : 16-10-2019=========

Please Install Node.js on your server before use our application which is required for realtime chat

------Amentotech--------
For more information you can contact us at our support forum : https://amentotech.ticksy.com/

====Package Include====
-[doctreat.zip] Main Theme which include demo content and all plugins.
-[documentation] It include Theme documentation.
-[doctreat-child] It include child theme for Doctreat. Child theme is better to customize theme.
-[plugins] It include all supporting plugins.
-[email-templates] All the email templates
-[import-users-sample] import users file format
-[product-explainer-intro] into video editable file